package com.multi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator extends JFrame implements ActionListener {

    ImageIcon icon = new ImageIcon("calbg.jpg");
    Image icon2 = icon.getImage().getScaledInstance(500,600, Image.SCALE_SMOOTH);
    ImageIcon icon3 = new ImageIcon(icon2);

    ImageIcon icon4 = new ImageIcon("home3.jpg");
    Image icon5 = icon4.getImage().getScaledInstance(40,40, Image.SCALE_SMOOTH);
    ImageIcon icon6 = new ImageIcon(icon5);

    JButton back_button;
    JPanel panel;
    JLabel bg_label;
    JButton[] numberb = new JButton[10];
    JButton[] functionb = new JButton[9];
    JButton addbutton,subbutton,mulbutton,divbutton,decbutton,equbutton,negbutton,clearbutton,deletebutton;
    JTextField textField;
    double num1=0,num2=0,result=0;
    char operator;

    Calculator(){

        back_button = new JButton();
        back_button.setBounds(0,0,40,40);
        back_button.setFocusable(false);
        back_button.setIcon(icon6);
        back_button.addActionListener(this);
        back_button.setVisible(true);

        bg_label = new JLabel(icon3);
        bg_label.setBounds(0,0,500,600);
        bg_label.setOpaque(true);
        bg_label.setVisible(true);

        textField = new JTextField();
        textField.setBounds(90,100,300,40);
        textField.setBackground(new Color(100,200,150));
        textField.setEditable(false);
        textField.setVisible(true);
        textField.setOpaque(true);
        textField.setBorder(BorderFactory.createEmptyBorder());
        textField.setFont(new Font("Comics",Font.BOLD,25));

        addbutton = new JButton("+");
        subbutton = new JButton("-");
        mulbutton = new JButton("*");
        divbutton = new JButton("/");
        equbutton= new JButton("=");
        decbutton = new JButton(".");
        clearbutton = new JButton("Clear");
        deletebutton = new JButton("Delete");
        negbutton = new JButton("(-)");

        clearbutton.setBounds(90,500,80,40);
        clearbutton.setFont(new Font("mv boli",Font.BOLD,20));
        negbutton.setBounds(200,500,80,40);
        negbutton.setFont(new Font("mv boli",Font.BOLD,20));
        deletebutton.setBounds(310,500,80,40);
        deletebutton.setFont(new Font("mv boli",Font.BOLD,20));

        functionb[0]=addbutton;
        functionb[1]=subbutton;
        functionb[2]=mulbutton;
        functionb[3]=divbutton;
        functionb[4]=decbutton;
        functionb[5]=equbutton;
        functionb[6]=deletebutton;
        functionb[7]=clearbutton;
        functionb[8]=negbutton;

        for (int i=0; i<9; i++){
            functionb[i].addActionListener(this);
            functionb[i].setFont(new Font("mv boli",Font.BOLD,20));
            functionb[i].setFocusable(false);
            functionb[i].setBorder(BorderFactory.createRaisedBevelBorder());
        }
        for (int i = 0 ; i<10;i++){
            numberb[i] = new JButton(String.valueOf(i));
            numberb[i].setFocusable(false);
            numberb[i].addActionListener(this);
            numberb[i].setFont(new Font("mv boli",Font.BOLD,25));
            numberb[i].setBorder(BorderFactory.createRaisedBevelBorder());
        }

        panel = new JPanel();
        panel.setBounds(90,160,300,300);
        panel.setLayout(new GridLayout(4,4,5,5));
        panel.setVisible(true);
        panel.setBackground(new Color(100,200,150));

        panel.add(numberb[1]);
        panel.add(numberb[2]);
        panel.add(numberb[3]);
        panel.add(addbutton);
        panel.add(numberb[4]);
        panel.add(numberb[5]);
        panel.add(numberb[6]);
        panel.add(subbutton);
        panel.add(numberb[7]);
        panel.add(numberb[8]);
        panel.add(numberb[9]);
        panel.add(mulbutton);
        panel.add(decbutton);
        panel.add(numberb[0]);
        panel.add(divbutton);
        panel.add(equbutton);

        bg_label.add(panel);
        bg_label.add(textField);
        bg_label.add(deletebutton);
        bg_label.add(negbutton);
        bg_label.add(clearbutton);
        bg_label.add(back_button);

        this.add(bg_label);
        this.setBounds(0,0,500,600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setTitle("Calculator");
        this.setResizable(false);
        this.setUndecorated(true);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.LIGHT_GRAY);
        this.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource()==back_button){
            Main main= new Main();
            this.dispose();
        }

        for (int i = 0 ; i<10;i++){
            if (e.getSource()==numberb[i]){
                textField.setText(textField.getText().concat(String.valueOf(i)));
            }
        }
        if (e.getSource()==decbutton){
            textField.setText(textField.getText().concat("."));
        }
        if (e.getSource()==addbutton){
            num1=Double.parseDouble(textField.getText());
            operator='+';
            textField.setText("");
        }
        if (e.getSource()==subbutton){
            num1=Double.parseDouble(textField.getText());
            operator='-';
            textField.setText("");
        }
        if (e.getSource()==mulbutton){
            num1=Double.parseDouble(textField.getText());
            operator='*';
            textField.setText("");
        }
        if (e.getSource()==divbutton){
            num1=Double.parseDouble(textField.getText());
            operator='/';
            textField.setText("");
        }
        if (e.getSource()==equbutton){
            num2= Double.parseDouble(textField.getText());

            switch(operator){
                case'+':
                    result=num1+num2;
                    break;
                case'-':
                    result=num1-num2;
                    break;
                case'*':
                    result=num1*num2;
                    break;
                case'/':
                    result=num1/num2;
                    break;
            }
            textField.setText(String.valueOf(result));
            num1=result;
        }
        if (e.getSource()==clearbutton){
            textField.setText("");
        }
        if (e.getSource()==deletebutton){
            String s = textField.getText();
            textField.setText("");
            for (int i=0;i<s.length()-1;i++){
                textField.setText(textField.getText()+s.charAt(i));
            }
        }
        if (e.getSource()==negbutton){
            double temp = Double.parseDouble(textField.getText());
            temp*=-1;
            textField.setText(String.valueOf(temp));
        }

    }
}


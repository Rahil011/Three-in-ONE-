package com.multi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Stopwatch extends JFrame implements ActionListener {

    ImageIcon icon = new ImageIcon("swbg1.jpg");
    Image icon2 = icon.getImage().getScaledInstance(500,600, Image.SCALE_SMOOTH);
    ImageIcon icon3 = new ImageIcon(icon2);

    ImageIcon icon4 = new ImageIcon("home3.jpg");
    Image icon5 = icon4.getImage().getScaledInstance(50,50, Image.SCALE_SMOOTH);
    ImageIcon icon6 = new ImageIcon(icon5);

    ImageIcon image7 = new ImageIcon("Start.png");
    Image image8 = image7.getImage().getScaledInstance(140,50, Image.SCALE_SMOOTH);
    ImageIcon image9 = new ImageIcon(image8);

    ImageIcon image10 = new ImageIcon("stop.png");
    Image image11 = image10.getImage().getScaledInstance(140,50, Image.SCALE_SMOOTH);
    ImageIcon image12 = new ImageIcon(image11);

    ImageIcon image13 = new ImageIcon("reset.png");
    Image image14 = image13.getImage().getScaledInstance(140,50, Image.SCALE_SMOOTH);
    ImageIcon image15 = new ImageIcon(image14);

    JLabel bg_label = new JLabel(icon3);
    JLabel time_label ;
    JButton start_button;
    JButton reset_button;
    JButton back_button;
    boolean started = false;
    int elapsed_time = 0;
    int hours=0;
    int min=0;
    int sec=0;
    String hour = String.format("%02d",hours);
    String minutes = String.format("%02d",min);
    String seconds = String.format("%02d",sec);

    Timer time = new Timer(1000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            elapsed_time += 1000;
            hours = (elapsed_time/3600000)%60;
            min = (elapsed_time/60000)%60;
            sec = (elapsed_time/1000)%60;
            String hour = String.format("%02d",hours);
            String minutes = String.format("%02d",min);
            String seconds = String.format("%02d",sec);

            time_label.setText(hour+":"+minutes+":"+seconds);
        }
    });

    Stopwatch(){

        start_button = new JButton();
        start_button.setBounds(50,350,128,40);
        start_button.setFocusable(false);
        start_button.setVisible(true);
        start_button.setIcon(image9);
        start_button.setBorder(BorderFactory.createEmptyBorder());
        start_button.addActionListener(this);
        
        reset_button = new JButton();
        reset_button.setBounds(300,350,128,40);
        reset_button.setFocusable(false);
        reset_button.setVisible(true);
        reset_button.setIcon(image15);
        reset_button.setBorder(BorderFactory.createEmptyBorder());
        reset_button.addActionListener(this);
        

        time_label = new JLabel();
        time_label.setBounds(90,150,350,200);
        time_label.setVisible(true);
        time_label.setText(hour+":"+minutes+":"+seconds);
        time_label.setForeground(new Color(200,90,100));
        time_label.setFont(new Font("MV boli",Font.BOLD,60));
        time_label.setBorder(BorderFactory.createEmptyBorder());

        back_button = new JButton();
        back_button.setBounds(0,0,50,50);
        back_button.setFocusable(false);
        back_button.setIcon(icon6);
        back_button.addActionListener(this);
        back_button.setVisible(true);

        bg_label.setBounds(0,0,500,600);
        bg_label.setOpaque(true);
        bg_label.add(back_button);
        bg_label.add(time_label);
        bg_label.add(start_button);
        bg_label.add(reset_button);
        bg_label.setVisible(true);

        this.add(bg_label);
        this.setSize(500,600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==back_button){
            Main main = new Main();
            this.dispose();
        }

        if (e.getSource()==start_button){
            if (started==false) {
                started=true;
                start_button.setIcon(image12);
                start();
            }
            else{
                started=false;
                start_button.setIcon(image9);
                stop();
            }
        }
        if (e.getSource()==reset_button){
            reset();
            start_button.setIcon(image9);
        }

    }
    void start(){
     time.start();
    }
    void stop(){
      time.stop();
    }
    void reset(){
      time.stop();
        int elapsed_time = 0;
        int hours=0;
        int min=0;
        int sec=0;
        String hour = String.format("%02d",hours);
        String minutes = String.format("%02d",min);
        String seconds = String.format("%02d",sec);

        time_label.setText(hour+":"+minutes+":"+seconds);
    }
}

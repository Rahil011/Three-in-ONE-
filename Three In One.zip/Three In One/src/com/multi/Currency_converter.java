package com.multi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Currency_converter extends JFrame implements ActionListener {

    ImageIcon icon = new ImageIcon("currency bg.jpg");
    Image icon2 = icon.getImage().getScaledInstance(500, 600, Image.SCALE_SMOOTH);
    ImageIcon icon3 = new ImageIcon(icon2);

    ImageIcon icon4 = new ImageIcon("home3.jpg");
    Image icon5 = icon4.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
    ImageIcon icon6 = new ImageIcon(icon5);

    ImageIcon image7 = new ImageIcon("convert.png");
    Image image8 = image7.getImage().getScaledInstance(130,45, Image.SCALE_SMOOTH);
    ImageIcon image9 = new ImageIcon(image8);

    String[] currency1 = {"Indian", " US Dollor", " Bitcoin", " Chinese yuan", " Euro ", " Jap.Yen", "Pak. Rupee", "UAE Dhiram "};
    String[] currency2 = {"Indian", " US Dollor", " Bitcoin", " Chinese yuan", " Euro ", " Jap.Yen", "Pak. Rupee", "UAE Dhiram "};

    JComboBox frombox;
    JComboBox tobox;
    JButton back_button;
    JButton convert_button;
    JTextField amt_field;
    JLabel from_label;
    JLabel to_label;
    JLabel enter_amt_label;
    JLabel result;
    JLabel bg_label;
    JLabel result_label;
    double a,c=0;

    Currency_converter() {
        result_label = new JLabel();
        result_label.setBounds(150, 450, 200, 30);
        result_label.setBackground(new Color(100, 100, 100));
        result_label.setForeground(Color.WHITE);
        result_label.setFont(new Font("mv boli", Font.BOLD, 20));
        result_label.setVisible(true);


        result = new JLabel();
        result.setBounds(210, 400, 200, 20);
        result.setVisible(true);
        result.setText("Result: ");
        result.setFont(new Font("mv boli", Font.BOLD, 18));
        result.setForeground(Color.red);
        result.setBorder(BorderFactory.createEmptyBorder());

        convert_button = new JButton();
        convert_button.setBorder(BorderFactory.createEmptyBorder());
        convert_button.setBounds(180, 350, 120, 30);
        convert_button.addActionListener(this);
        convert_button.setFocusable(false);
        convert_button.setIcon(image9);
        convert_button.setFont(new Font("college", Font.ITALIC, 18));
        convert_button.setVisible(true);

        amt_field = new JTextField();
        amt_field.setBounds(120, 290, 230, 30);
        amt_field.setFont(new Font("book script", Font.BOLD, 18));
        amt_field.setOpaque(true);
        amt_field.setVisible(true);

        enter_amt_label = new JLabel();
        enter_amt_label.setBounds(120, 250, 200, 20);
        enter_amt_label.setVisible(true);
        enter_amt_label.setText("Enter Amount: ");
        enter_amt_label.setFont(new Font("mv boli", Font.BOLD, 18));
        enter_amt_label.setForeground(Color.red);
        enter_amt_label.setBorder(BorderFactory.createEmptyBorder());


        frombox = new JComboBox(currency1);
        frombox.setBounds(200, 130, 150, 20);
        frombox.setVisible(true);
        frombox.addActionListener(this);

        from_label = new JLabel();
        from_label.setBounds(120, 130, 70, 20);
        from_label.setVisible(true);
        from_label.setText("From: ");
        from_label.setFont(new Font("mv boli", Font.BOLD, 18));
        from_label.setForeground(Color.red);
        from_label.setBorder(BorderFactory.createEmptyBorder());

        to_label = new JLabel();
        to_label.setBounds(120, 170, 70, 20);
        to_label.setVisible(true);
        to_label.setText("To: ");
        to_label.setFont(new Font("mv boli", Font.BOLD, 18));
        to_label.setForeground(Color.red);
        to_label.setBorder(BorderFactory.createEmptyBorder());


        tobox = new JComboBox(currency2);
        tobox.setBounds(200, 170, 150, 20);
        tobox.setVisible(true);
        tobox.addActionListener(this);
        tobox.setSelectedItem("US Dollor");


        back_button = new JButton(icon6);
        back_button.setBounds(0, 0, 40, 40);
        back_button.setFocusable(false);
        back_button.setIcon(icon6);
        back_button.addActionListener(this);
        back_button.setVisible(true);

        bg_label = new JLabel(icon3);
        bg_label.setBounds(0, 0, 500, 600);
        bg_label.setOpaque(true);
        bg_label.setVisible(true);
        bg_label.add(back_button);
        bg_label.add(from_label);
        bg_label.add(frombox);
        bg_label.add(convert_button);
        bg_label.add(to_label);
        bg_label.add(result_label);
        bg_label.add(result);
        bg_label.add(tobox);
        bg_label.add(enter_amt_label);
        bg_label.add(amt_field);

        this.add(bg_label);
        this.setBounds(0, 0, 500, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.LIGHT_GRAY);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == back_button) {
            Main main = new Main();
            this.dispose();
        }
//        .....................................................
        if (frombox.getSelectedIndex()==0 && tobox.getSelectedIndex()==1){
            a = Double.parseDouble(amt_field.getText());
            c=a/74.37;
        }
        if (frombox.getSelectedIndex()==0 && tobox.getSelectedIndex()==2){
            a = Double.parseDouble(amt_field.getText());
            c=a/3411791.32;
        }
        if (frombox.getSelectedIndex()==0 && tobox.getSelectedIndex()==3){
            a = Double.parseDouble(amt_field.getText());
            c=a/11.47;
        }
        if (frombox.getSelectedIndex()==0 && tobox.getSelectedIndex()==4){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==0 && tobox.getSelectedIndex()==5){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==0 && tobox.getSelectedIndex()==6){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==0 && tobox.getSelectedIndex()==7){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//        ..........................................................................

        if (frombox.getSelectedIndex()==1 && tobox.getSelectedIndex()==0){
            a = Double.parseDouble(amt_field.getText());
            c=a*74.18;
        }
        if (frombox.getSelectedIndex()==1 && tobox.getSelectedIndex()==2){
            a = Double.parseDouble(amt_field.getText());
            c=a/45902.60;
        }
        if (frombox.getSelectedIndex()==1 && tobox.getSelectedIndex()==3){
            a = Double.parseDouble(amt_field.getText());
            c=a*6.49;
        }
        if (frombox.getSelectedIndex()==1 && tobox.getSelectedIndex()==4){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==1 && tobox.getSelectedIndex()==5){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==1 && tobox.getSelectedIndex()==6){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==1 && tobox.getSelectedIndex()==7){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//....................................................................................

        if (frombox.getSelectedIndex()==2 && tobox.getSelectedIndex()==0){
            a = Double.parseDouble(amt_field.getText());
            c=a/74.18;
        }
        if (frombox.getSelectedIndex()==2 && tobox.getSelectedIndex()==1){
            a = Double.parseDouble(amt_field.getText());
            c=a/280726.26;;
        }
        if (frombox.getSelectedIndex()==2 && tobox.getSelectedIndex()==3){
            a = Double.parseDouble(amt_field.getText());
            c=a/11.48;
        }
        if (frombox.getSelectedIndex()==2 && tobox.getSelectedIndex()==4){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==2 && tobox.getSelectedIndex()==5){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==2 && tobox.getSelectedIndex()==6){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==2 && tobox.getSelectedIndex()==7){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//        ...................................................................................

        if (frombox.getSelectedIndex()==3 && tobox.getSelectedIndex()==0){
            a = Double.parseDouble(amt_field.getText());
            c=a/74.18;
        }
        if (frombox.getSelectedIndex()==3 && tobox.getSelectedIndex()==1){
            a = Double.parseDouble(amt_field.getText());
            c=a/280726.26;;
        }
        if (frombox.getSelectedIndex()==3 && tobox.getSelectedIndex()==2){
            a = Double.parseDouble(amt_field.getText());
            c=a/11.48;
        }
        if (frombox.getSelectedIndex()==3 && tobox.getSelectedIndex()==4){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==3 && tobox.getSelectedIndex()==5){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==3 && tobox.getSelectedIndex()==6){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==3 && tobox.getSelectedIndex()==7){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//        ...................................................................................

        if (frombox.getSelectedIndex()==4 && tobox.getSelectedIndex()==0){
            a = Double.parseDouble(amt_field.getText());
            c=a/74.18;
        }
        if (frombox.getSelectedIndex()==4 && tobox.getSelectedIndex()==1){
            a = Double.parseDouble(amt_field.getText());
            c=a/280726.26;;
        }
        if (frombox.getSelectedIndex()==4 && tobox.getSelectedIndex()==2){
            a = Double.parseDouble(amt_field.getText());
            c=a/11.48;
        }
        if (frombox.getSelectedIndex()==4 && tobox.getSelectedIndex()==3){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==4 && tobox.getSelectedIndex()==5){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==4 && tobox.getSelectedIndex()==6){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==4 && tobox.getSelectedIndex()==7){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//        ...................................................................................

        if (frombox.getSelectedIndex()==5 && tobox.getSelectedIndex()==0){
            a = Double.parseDouble(amt_field.getText());
            c=a/74.18;
        }
        if (frombox.getSelectedIndex()==5 && tobox.getSelectedIndex()==1){
            a = Double.parseDouble(amt_field.getText());
            c=a/280726.26;;
        }
        if (frombox.getSelectedIndex()==5 && tobox.getSelectedIndex()==2){
            a = Double.parseDouble(amt_field.getText());
            c=a/11.48;
        }
        if (frombox.getSelectedIndex()==5 && tobox.getSelectedIndex()==3){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==5 && tobox.getSelectedIndex()==4){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==5 && tobox.getSelectedIndex()==6){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==5 && tobox.getSelectedIndex()==7){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//        ...................................................................................

        if (frombox.getSelectedIndex()==6 && tobox.getSelectedIndex()==0){
            a = Double.parseDouble(amt_field.getText());
            c=a/74.18;
        }
        if (frombox.getSelectedIndex()==6 && tobox.getSelectedIndex()==1){
            a = Double.parseDouble(amt_field.getText());
            c=a/280726.26;;
        }
        if (frombox.getSelectedIndex()==6 && tobox.getSelectedIndex()==2){
            a = Double.parseDouble(amt_field.getText());
            c=a/11.48;
        }
        if (frombox.getSelectedIndex()==6 && tobox.getSelectedIndex()==3){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==6 && tobox.getSelectedIndex()==4){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==6 && tobox.getSelectedIndex()==5){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==6 && tobox.getSelectedIndex()==7){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//        ...................................................................................

        if (frombox.getSelectedIndex()==7 && tobox.getSelectedIndex()==0){
            a = Double.parseDouble(amt_field.getText());
            c=a/74.18;
        }
        if (frombox.getSelectedIndex()==7 && tobox.getSelectedIndex()==1){
            a = Double.parseDouble(amt_field.getText());
            c=a/280726.26;;
        }
        if (frombox.getSelectedIndex()==7 && tobox.getSelectedIndex()==2){
            a = Double.parseDouble(amt_field.getText());
            c=a/11.48;
        }
        if (frombox.getSelectedIndex()==7 && tobox.getSelectedIndex()==3){
            a = Double.parseDouble(amt_field.getText());
            c=a/88.13;
        }
        if (frombox.getSelectedIndex()==7 && tobox.getSelectedIndex()==4){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.68;
        }
        if (frombox.getSelectedIndex()==7 && tobox.getSelectedIndex()==5){
            a = Double.parseDouble(amt_field.getText());
            c=a/0.45;
        }
        if (frombox.getSelectedIndex()==7 && tobox.getSelectedIndex()==6){
            a = Double.parseDouble(amt_field.getText());
            c=a/20.20;
        }
//        ...................................................................................

        if (e.getSource()==convert_button){
            result_label.setText(String.valueOf(c));
        }
    }
}

package com.multi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Main implements ActionListener  {
    JFrame frame;
    JLabel label;
    JLabel tio_label;
    JLabel s_label;
    JLabel c_label;
    JLabel cc_label;
    JLabel e_label;
    JLabel name_label;
    JButton cal_button = new JButton();
    JButton stopWatch_button = new JButton();
    JButton converter_button = new JButton();
    JButton exit_button = new JButton();

    ImageIcon image = new ImageIcon("mainbg1.jpg");
    Image image2 = image.getImage().getScaledInstance(500,600, Image.SCALE_SMOOTH);
    ImageIcon image3 = new ImageIcon(image2);

    ImageIcon image4 = new ImageIcon("calLogo1.jpg");
    Image image5 = image4.getImage().getScaledInstance(43,43, Image.SCALE_SMOOTH);
    ImageIcon image6 = new ImageIcon(image5);

    ImageIcon image7 = new ImageIcon("swl1.jpg");
    Image image8 = image7.getImage().getScaledInstance(45,45, Image.SCALE_SMOOTH);
    ImageIcon image9 = new ImageIcon(image8);

    ImageIcon image10 = new ImageIcon("cc1.jpg");
    Image image11 = image10.getImage().getScaledInstance(40,40, Image.SCALE_SMOOTH);
    ImageIcon image12 = new ImageIcon(image11);

    ImageIcon image13 = new ImageIcon("exit.jpg");
    Image image14 = image13.getImage().getScaledInstance(40,40, Image.SCALE_SMOOTH);
    ImageIcon image15 = new ImageIcon(image14);

    ImageIcon image16 = new ImageIcon("calculator.png");
    Image image17 = image16.getImage().getScaledInstance(160,60, Image.SCALE_SMOOTH);
    ImageIcon image18 = new ImageIcon(image17);

    ImageIcon image19 = new ImageIcon("stopwatch.png");
    Image image20 = image19.getImage().getScaledInstance(160,60, Image.SCALE_SMOOTH);
    ImageIcon image21 = new ImageIcon(image20);

    ImageIcon image22 = new ImageIcon("cconverter.png");
    Image image23 = image22.getImage().getScaledInstance(160,70, Image.SCALE_SMOOTH);
    ImageIcon image24 = new ImageIcon(image23);

    ImageIcon image25 = new ImageIcon("exit1.png");
    Image image26 = image25.getImage().getScaledInstance(140,40, Image.SCALE_SMOOTH);
    ImageIcon image27 = new ImageIcon(image26);

    ImageIcon image28 = new ImageIcon("three in one.png");
    Image image29 = image28.getImage().getScaledInstance(200,200, Image.SCALE_SMOOTH);
    ImageIcon image30 = new ImageIcon(image29);

    Main() {

        tio_label = new JLabel(image30);
        tio_label.setBounds(70,30,200,200);
        tio_label.setBackground(Color.LIGHT_GRAY);
        tio_label.setVisible(true);

        s_label = new JLabel(image6);
        s_label.setBounds(310,280,40,40);
        s_label.setOpaque(true);
        s_label.setBackground(Color.black);
        s_label.setVisible(true);

        c_label = new JLabel(image9);
        c_label.setBounds(310,330,40,40);
        c_label.setOpaque(true);
        c_label.setBorder(BorderFactory.createEmptyBorder());
        c_label.setBackground(Color.black);
        c_label.setVisible(true);

        cc_label = new JLabel(image12);
        cc_label.setBounds(310,380,40,40);
        cc_label.setOpaque(true);
        cc_label.setBackground(Color.black);
        cc_label.setVisible(true);

        e_label = new JLabel(image15);
        e_label.setBounds(310,430,40,40);
        e_label.setOpaque(true);
        e_label.setBackground(Color.black);
        e_label.setVisible(true);

        name_label = new JLabel();
        name_label.setBounds(385,582,130,15);
        name_label.setVisible(true);
        name_label.setText( "by  ~  Rahil Khan");
        name_label.setForeground(Color.red);
        name_label.setFont(new Font("mv boli",Font.ITALIC,12));
        name_label.setBorder(BorderFactory.createEmptyBorder());
//  ....................................................................
        cal_button.setBounds(150,280,150,40);
        cal_button.setFocusable(false);
        cal_button.setVisible(true);
        cal_button.setBorder(BorderFactory.createEmptyBorder());
        cal_button.setIcon(image18);
        cal_button.addActionListener(this);

        stopWatch_button.setBounds(150,330,150,40);
        stopWatch_button.setFocusable(false);
        stopWatch_button.setVisible(true);
        stopWatch_button.setBorder(BorderFactory.createEmptyBorder());
        stopWatch_button.setIcon(image21);
        stopWatch_button.addActionListener(this);

        converter_button.setBounds(150,380,155,40);
        converter_button.setFocusable(false);
        converter_button.setVisible(true);
        converter_button.setBorder(BorderFactory.createEmptyBorder());
        converter_button.setIcon(image24);
        converter_button.addActionListener(this);

        exit_button.setBounds(160,430,128,40);
        exit_button.setFocusable(false);
        exit_button.setVisible(true);
        exit_button.setBorder(BorderFactory.createEmptyBorder());
        exit_button.setIcon(image27);
        exit_button.addActionListener(this);

        label = new JLabel(image3);
        label.setBounds(0,0,500,600);
        label.setOpaque(true);

        label.add(cal_button);
        label.add(converter_button);
        label.add(stopWatch_button);
        label.add(exit_button);
        label.add(tio_label);
        label.add(s_label);
        label.add(c_label);
        label.add(cc_label);
        label.add(e_label);
        label.add(name_label);
        label.setVisible(true);
//   ..........................................................
        frame = new JFrame();
        frame.add(label);
        frame.setSize(500, 600);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setUndecorated(true);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource()==stopWatch_button){
         Stopwatch stopwatch = new Stopwatch();
        }
        if (e.getSource()==cal_button){
            Calculator calculator = new Calculator();
        }
        if (e.getSource()==converter_button){
            Currency_converter currency_converter = new Currency_converter();
        }
        if (e.getSource()==exit_button){
            frame.dispose();
        }

    }

    public static void main(String[] args) {
        Main main = new Main();
    }
}
